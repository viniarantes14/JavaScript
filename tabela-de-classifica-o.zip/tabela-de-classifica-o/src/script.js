var Vini = {
  nome: "Vini",
  vitorias: 0,
  empates: 0,
  derrotas: 0,
  pontos: 0 
}
var Sarah = {
  nome: "Sarah",
  vitorias: 0,
  empates: 0,
  derrotas: 0,
  pontos: 0
}

Vini.pontos = calculaPontos(Vini)
Sarah.pontos = calculaPontos(Sarah)

function calculaPontos(jogador){
  var pontos = (jogador.vitorias *3) + jogador.empates 
 return pontos
}

var jogadores = [Vini, Sarah]

exibirJogadoresNaTela(jogadores)

function exibirJogadoresNaTela (jogadores){
  html =""
  for (var i = 0; i < jogadores.length; i++){
    html += "<tr><td>" + jogadores[i].nome + "</td>"
    html += "<td>" + jogadores[i].vitorias + "</td>"
    html += "<td>" + jogadores[i].empates + "</td>"
    html += "<td>" + jogadores[i].derrotas + "</td>"
    html += "<td>" + jogadores[i].pontos + "</td>"
    html += "<td><button onClick = 'adicionarVitoria(" + i + ")'>Vitoria</button></td>" 
        html += "<td><button onClick = 'adicionarEmpate(" + i + ")'>Empate</button></td>" 
        html += "<td><button onClick = 'adicionarDerrota(" + i + ")'>Derrota</button></td></tr>" 
  }
  var tabelaJogadores = document.getElementById("tabelaJogadores")
  tabelaJogadores.innerHTML = html
}

function adicionarVitoria(i){
  var jogador = jogadores[i]
  jogador.vitorias++
  jogador.pontos = calculaPontos(jogador)
  exibirJogadoresNaTela(jogadores)
}

function adicionarEmpate(i){
  var jogador = jogadores[i]
  jogador.empates++
  jogador.pontos = calculaPontos(jogador)
  exibirJogadoresNaTela(jogadores)
}

function adicionarDerrota(i){
  var jogador = jogadores[i]
  jogador.derrotas++
  exibirJogadoresNaTela(jogadores)
}

//Um objeto em um código é uma variavel que posui varias informações dentro dele, neste caso o exemplo possui nome, vitorias, empates, derrotas e pontos 
// É possivel ccriar funções com variaveis que serão declaradas previamente ou posteriormente
// Html += é equivalente a html = html + .... / assim como var.vitorias = var.vitorias + vitoria
// getElementById é uma função usada no javaScript para buscar coisas no html assim como  document.write
// var.length significa o tamanho do array, lembrando que o primeiro elemento é sempre o elemento 0 depois o 1 e assim por diante
//é possivel adicionar um botão para se clicar com um inner html <button onClick
