var numeroSecreto = parseInt(Math.random() * 10)

var vidas = 3

while (vidas > 0){
var chute = parseInt(prompt("Escolha um número de 0 a 9")) 


 if(numeroSecreto == chute){
   alert("Acertou!!")
  break
}else if (numeroSecreto > chute) {
  alert ("O numero secreto é maior ")
  vidas = vidas -1

} else if (numeroSecreto < chute) {
 alert ("O numero secreto é menor")
 vidas = vidas -1
}
}
if (chute != numeroSecreto){
  alert("Você perdeu! O número secreto era " + numeroSecreto)
  }
/*while serve para rodar o programa até certa condição ser cumrpida
diferente de if e else if que rodam apenas uma vez */
//document.write serve para exibir mensagens na propria tela sem um pop up e sim na propria imagem 