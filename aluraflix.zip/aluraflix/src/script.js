var animes = ["https://sucodemanga.com.br/wp-content/uploads/2014/12/no-game-no-life-thumb.jpg", "https://uploads.jovemnerd.com.br/wp-content/uploads/2020/09/horimiya-anime-anunciado.jpg", "http://1.bp.blogspot.com/-Ez1EYzNm3Ac/UlY74V001AI/AAAAAAAAAjk/i45dRcmvr7M/s1600/01.jpg" ]

for (var i = 0 ; i < animes.length; i ++){
  document.write("<img src=" + animes[i] + ">")
}


//console.log("X") é a forma usada para realizar testes no codigo sem aparecer na interface do usuário, tais coisas podem ser vistas e executadas no console
//array [] é uma forma utilizada paa agrupar varais variaveis dentro de um mesmo lugar (sem ter que criar varias linhas) seus elementos são enumerados a partir do 0 e é possivel descobrir a quantidade de elementos atraves do comando console.lenght 
// para subistituir o while podemos usar a função for que da um "laço" entre os elementos do array
// for é escrito da forma: for(var "nome" = i; i < "nome".lenght; i ++) ou for(var "nome" = i; i  > "nome".lenght; i --)
// i ++ equivale a i= i + 1 e i-- equivale a i= i -1