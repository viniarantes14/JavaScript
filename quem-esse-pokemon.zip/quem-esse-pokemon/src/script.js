var primeiroValor = prompt("Quem é esse pokemon? 1-charmander, 2-bulbassauro, 3-squirtle, 4-pikachu ?")

if (primeiroValor == 1)  {
  document.write('<h2>Tente Novamente</h2>') 
} else if (primeiroValor == 2) {
  document.write('<h2>Tente Novamente</h2>')
} else if (primeiroValor == 3) {
  document.write('<h2>Tente Novamente</h2>')
} else if (primeiroValor == 4) {
  document.write('<h2>Acertou!!! Parabéns</h2>')
}
else 
  document.write('<h2>Tente Novamente</h2>')

