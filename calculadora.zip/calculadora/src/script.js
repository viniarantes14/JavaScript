var primeiroValor = parseInt(prompt("Insira um número"))
var segundoValor = parseInt(prompt("Insira um número"))
var operação = prompt( "1-Soma, 2-Subtração, 3-Multiplicação, 4-Divisão ")

if (operação == 1) {
  var resultado = primeiroValor + segundoValor
  document.write("<h2>" + primeiroValor + " + " + segundoValor + " = " + resultado + "</h2>") 
} else if (operação == 2) {
  var resultado = primeiroValor - segundoValor
  document.write("<h2>" + primeiroValor + "-" + segundoValor + "=" + resultado + "</h2>")
} else if (operação == 3) {
  var resultado = primeiroValor * segundoValor
  document.write("<h2>" + primeiroValor + "X" + segundoValor + "=" + resultado + "</h2>")
} else if (operação == 4) {
  var resultado = primeiroValor / segundoValor
  document.write("<h2>" + primeiroValor + "/" + segundoValor + "=" + resultado + "</h2>")
} else 
  document.write("<h2>insira um número</h2>")

//revisão:
//If-indica uma condição para uma coisa ser acionada no sistema, precisa vir sempreacompanhado de uma condiçao em parenteses para ser verificada e seguido de chaves para expessificar o que ser feito caso a mesma seja obedecida, podendo ser adicionados varios ifs atraves do else if 

//para encobrir qualquer outro caso que não os especificados pelo if e pelos else if adicionasse o else para executar essa ação, sendo o else não acompanhado de chaves 