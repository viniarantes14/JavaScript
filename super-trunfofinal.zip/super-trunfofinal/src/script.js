var cartaA = {
    nome: "Seiya de Pegaso",
    imagem: "https://i.pinimg.com/originals/c2/1a/ac/c21aacd5d092bf17cfff269091f04606.jpg",
    atributos: {
        Atk: 8,
        Mgk: 9,
        Intel: 6,
    }
}

var cartaB = {
    nome: "Bulbasauro",
    imagem: "http://4.bp.blogspot.com/-ZoCqleSAYNc/UQgfMdobjUI/AAAAAAAACP0/s_iiWjmw2Ys/s1600/001Bulbasaur_Dream.png",
    atributos: {
        Atk: 7,
        Mgk: 6,
        Intel: 4,
    }
}

var cartaC = {
    nome: "Lorde Darth Vader",
    imagem: "https://images-na.ssl-images-amazon.com/images/I/51VJBqMZVAL._SX328_BO1,204,203,200_.jpg",
    atributos: {
        Atk: 8,
        Mgk: 9,
        Intel: 7,
    }
}

var cartaD = {
    nome: "Caitlyn",
    imagem: "http://1.bp.blogspot.com/-K7CbqWc1-p0/VLc98v85s0I/AAAAAAAABqk/-ZB684VVHbg/s1600/Caitlyn_OriginalSkin.jpg",
     atributos: {
        Atk: 9,
        Mgk: 1,   
        Intel: 4,
    }
}

var cartaE = {
    nome: "Naruto",
    imagem: "https://conteudo.imguol.com.br/c/entretenimento/16/2017/06/27/naruto-1498593686428_v2_450x337.png",
    atributos: {
        Atk: 8,
        Mgk: 10,
        Intel: 6,
    }
}

var cartaF = {
    nome: "Harry Potter",
    imagem: "https://sm.ign.com/ign_br/screenshot/default/89ff10dd-aa41-4d17-ae8f-835281ebd3fd_49hp.jpg",
    atributos: {
        Atk: 5,
        Mgk: 10,
        Intel:8,
    }
}

var cartaG = {
    nome: "Batman",
    imagem: "https://assets.b9.com.br/wp-content/uploads/2020/09/Batman-issue86-heder-1280x677.jpg",
    atributos: {
        Atk: 9,
        Mgk: 0,
        Intel: 10,
    }
}

var cartaH = {
    nome: "Capitã Marvel",
    imagem: "https://cinepop.com.br/wp-content/uploads/2018/09/capitamarvel21.jpg",
    atributos: {
        Atk: 9,
        Mgk: 6,
        Intel: 4,
    }
}

var cartaI = {
  nome: "Edward Elric",
  imagem: "https://lh5.googleusercontent.com/-sR0yB9F8r7g/TXF4-XZG6HI/AAAAAAAABVw/GhXHKqbpbD4/s1600/Edward_Elric_wallpaper.jpg",
  atributos: {
    Atk: 7,
    Mgk: 8,
    Intel: 6,
  }
}

var cartaJ = {
  nome: "Light Yagami",
  imagem: "https://wallpapercave.com/wp/pUTZ2kr.jpg",
  atributos: {
    Atk: 4,
    Mgk: 5,
    Intel: 10,
  }
}

var cartaK ={
  nome: "Eren Yeaguer",
  imagem : "https://i.ytimg.com/vi/jXYk0Si9KDk/maxresdefault.jpg",
  atributos: {
    Atk: 9,
    Mgk: 6,
    Intel: 4,
  }
}

var cartaL = {
  nome: "Assuna",
  imagem: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxQTExYUFBMWFxYYGhwcGRkXGh8ZGBseFxgYGRweGRwhHykjIB4mHBkaIjIjJiosLy8vGyA1OjctOSkvLywBCgoKDg0OHBAQHDEmIScxLjAwLi4uLi4uMDAuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLv/AABEIATEApQMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAFBgAEAgMHAQj/xABIEAACAQIEAwUEBwUFBwMFAAABAhEAAwQSITEFQVEGEyJhcTKBkaEUI0JSscHRB2JyguEzQ5Ky8BU0U6LC0vEWk8NUY4Ojs//EABoBAAMBAQEBAAAAAAAAAAAAAAACAwEEBQb/xAAoEQADAAEEAQQCAgMBAAAAAAAAAQIRAxIhMUEEEyJRYXEUgTKRsSP/2gAMAwEAAhEDEQA/AO3BxXoNVNOTfGsxPIzUVqMdwi1UqsL0b1tW6KdWmY5aNlSvAa9pxSVKr4XEZ1kCPEy/4HZP+mvL2Mtpozqp6EgGsyGCxXtC8Rd7x1RG8JUszKd1mAFYbSdyOQqnxLiwtfVWgJUQYHhXyA6/611hauZWWPMOnhB+ak0iXsRdf2rjH36fAafKtGZx7Lken9CD865/5U/R0fxH9nQ6lJGC47eQgMc37rGZ65W3+O3Smrh/EEuiV3G4O4/p51bT1pvojqaNR2XalSpVSRKlSpQBKlSpQBKlSpQBpa0K1mzW5xzrUCSCajSX0UTZiZHn615p6fhW62Zr1rYrNmVwG41AkeY8qqf7SCErcnclWAJBBMgaayNvd51b7ojag3GcQuQm4YTWOWbLuSeQG3/kUjqoQ0yqeGUcdxIhmNl2VWktm2k7lRyn3GaCYwvuL0E6yxUSeslDP+taGf7OfE3Stm0V55mnMAdjmYkqCNgN/Oh3H+z+IwaZyq+Ix3qHMwJGiydUmD4gJMxOwPPe+uTv0YjcoTw2XsF2pxNq61m2EuXWhSxBATxQCwBIzAtqB5A6g5XQWrVwaEW35z7LHrNL3YLg9q5g2NkMtwsHD3AAzMme2JysQLftqFkmcx51p4pexEsqBUCA52J1WBJzCDBjYDN11kGmualJPlC04dtTw1x+w8+CcEnKSo0ldQT6jkPxnpQ/G4kqwt20zuRJE5VVZiXaDEkEAQSYPSrHD0NtFXMZAEmdSftEnzMmsbOJLy2YmSC0mdwMq/4cpPqOpqPDGzS7NeJwS3FCuOh0JEEdCIPWrmCBtEFCQRtJLe4yZI8pr3NQ9Furf77N9Q8IojZgJzTPNpXaiU+0FNNYY/4LEi4oYadR0NWKXOA4o96VJkOJE/eXf4gzTHXp6d7pyebc7awe1KlSnEJUqVKAJUqVKAMWFaTarfUpXKZqeDFVise8ExWyvCKGmugz9ntDsVw1blxXcBlUaKdRmkEGNtPxg8hV8ba/KvSaHhrkE2ugHibyYUXrtwgKzhgeZlFXL6yp+IpG432nu4odzaUBXI8JUMWgg6g6RIFXu2+CvYzHWsKhPdpbD3DsFzMwknrAHx56U08M4Fh8HbzKokDVjqx9J58hz1iuS4qm9vCO/TrS04VV8qfj6+gBwi5ds3bdq69t8lrM2fwqjHOUVTspMSWIJ+ArHj3F8LiEFvMly6j2Va4hypmYsfDrLqCpEagZx50K7SY1Us3XcKXunY6iTtE8kUCD+6OtaeC2Tbw1o5mDNcBddQIdgUn+UbHnmjY1k6vw2i1pfJV5CfEb5Fq8RqQrR6ldPmRVZLRtpaUklVUs0Ay5Myw6ySwj97N901Zs5XuNbbUF7Uj91iAfkhoRfs429j7Ss11LOcLcyraVUYLcOVBlYuEC22lyQYnKBAE9KFS5KatNPgv3MSxcj7WSSBqEA01/eLtEf/aimbEKq2GtxLIhZgNlZfrN/IwYEmCOoqcP4OLeUGCQQXYfbZfZiSSFnxxJg5RJApat8OP0nG4q+ItICqwxLKo75roXSFL+GVA1DgmTrVphIhV0wl2Wv52sXAeSz/PZtz/mp9pV7KcMIs2iwCkLakDqLSs2vMZyF/kprq+lG2cEdWt1ZJUqVKqSJUqVKAJUqVKABp4xaHtFl/iR1PwImttriNptBcWehMH4HWvH4hZ2Ny2fLMD8qEYxcK2zFT+6rR71iPhFSq2vKHmE/DGQVKSPpTWz4HYj91Wj3ow/I1bTtXl9s2z6tkPv3/AUi9RPT4KP09eORrY1WbUT50vP2ztbfVydh3on4RPyr25x9mAyLl6kgmPSQs+tLqas/ZsaN/Qae5btZnaAXiTzbKIAHoOXmTSxxvi+aWc5La6weXmep/8AA86eLxRJLMS56kwo9TtHxilHjPGUJ3F0rqB/cJ5x/eMOp06Co1qu/iujp09BT8n2euxxF9HcEKf7FDvlGpuMOS6SPvHKNhJ0cV40beKZlIyKBbYHVSFOZjHVW2PIoKu8PV7NtsRcDPiL3htqRLknVVjfWMxA2Cgcq04LsjfFu62IQBmBygsJGfNAIB8TmD6QSKIlt8D3SS5DOIVvpVvLvcttljm1kO4HvDEepFP1tEcrdCqWK6PAzZW1gNvHlXMWxb/RrV/MUu4e4M5G6z4W35DMp13Ag0w8B7cYe4RYuOEc+yRItkHSAw0XWQNegrdPrBLUTbyuhzIpd7e38mCdSdXyoPMkyfkCaPLHh1LE+zrvp8xB51yTtdxa7fxBDkBLTsqqPZENEnqTEz5cqo+hJWWdtw9sKoUCABW6oKldZxmGbWKyrw1hbJjUUueTcHlx4r1Lk1i6Hea9tKedJmtw3GDdUqVKqIc8xXHcEDlTPdforuT/APr0+JFUbqNe2tvaH71+4p/wq7/5hVNOL2LX1eHtl2OwQaH1Y6n11q5ZXEvq7LaH3UAZ/exkD3CvLq39YPVnTSN1rBZRqR6wT8S7NWyFI9osPImPlpQzGcTw9n2mNxxynOwPqTC+mnpQLH9qbr6JFseXib4n8hSqWxxsd7VkSclse5Z/U0Dx/a1BpaUufvNovw3PypRvXixlmLE8yZPxNYW1LmFEkbxsPNidFHmTVFpryZkucQ4rdvf2jyPu7KPd+ZorwPhIGS7eB8RAtW48TsfZ0PyB9TAGo/APYtNLnvru6qglAZEAEjxNrvEDkCYlr/Z1Ye/ibuJvGSi5bajVVLkgw25IAI6eIxPLe3tQUmo3scMNwprUOotteIgs5MIDBKpAmCQJOhMCdAALV+xdZSCQGIibeh58mkHc8xvuKvVKquOjjfPZzLE4YWsQ2HumbeJtlJMiXWdYOoJQj3qBS7wTgrW8RZVlXMzNbWNYIJynU9V29Tzrp3aPgS4zKIK3UZhbuhSQjBQwDkNMEENJEcpBIBF8S4aLOQXc3e3CqpcTXLdUnKxG+Vxl11y7VtQ87kho1FjbkacFbS2oRdGQopIEEkxr5zmPzrlXHbP118cwzke5yfwmmnE8duZwXUrcthQQRANwM4BGkECRt1ihHa7Dmzj7kiVYhx+8HXxfFs4paT27jdN4vB1+0ZUHqB+FZ0I4Ji89pNZhQJ6wBB94g++iqPNdMaio5KhpmVSK9qVQQ8ivalSgCVKlSgDk5axg08z73f8Ap8AKXuJ8Yu3R4j3Vs7KvtMPkSPPRapYrEEEvcOa62vi1CTtI2J6LsOYJ0FN3nxOWJbb7zecnYeZ908vNmPLPXbPRLGEU+7U+/wD0KwdVHtOo8l8R+Xh+deAPc8Kgkfctgx6kaknzMmscRg3tjxo6A/eBUfOKpgXJi91eSE+bH8hEfOtVy8SILQBsBAA9Bt8BWeGwpuNlVQT0JC/DMRNHcP2Fx7Rlw5APMsgH+amUsV0l2xft3yoOXSRBO2nPWJg843505cA4vfwCkXMOzIAfEh2nM4zDb2m3JAyjnuPbn7Obtu01y/dtoNAFSXJLHKATACiTqdYE10LgVu1ibC5hlur7WUw6EnWD0+IkdRVY0u2yNa8prjK/0c/xvbDDvcL96wkkpmViyjkPCCBHkeVH+zPbq3iG7rODcAkQpLuBvlU5cxAkwNTBgE77u0/ZNSUzdy0z4msWy0CNyRJPmTy2qjhuzdtRBd40OVItJoZHhQDn51q0sMTU1oa+Kf8AsNdssTdwuHU2ng37qW2uBYZA4aXHPNAUSZI+EXOF9hcHahzbNy7IbvXJNzNvmDTIM670H41wTF4vDtbs4gFQ4lLq5icuVwUuaFSDyOh6iivDe1ao64fEA2mVVDXH8NssTlVQTsxjZonlNNjnkxX/AOamXzzn8rjBU4oLfjw6gs+Hi8GiAQ05lcjTNEnkCco05ke2fZr6WqvbIF23OWdmB1yk8tdQfXrQzgPGLFj6XevXFUvfYamSQoAAHl8qv8K7Vd64FrD32s7Z8kBfQEyV8hPl0pJubWK8hWncVulcLz/QH7M8SfDv3F9Sjcg2k+U7ETMEaanrTtavAiVMj5j1qYjD2b65XVXA5EeJZ+an4UNv8PeyM1tmZRyOrgeX3x5b+ppHFR/jyjN833ww8prKgXCuN23IUsJIlSDoQeY8vPajs1bTtUskrhy8M9qVKlUEJUqVKAOD43stds2DicQckkBLZ1uOzawfu6SZJJ8qb/2Z9nbNyycTetpcuO5ClxmCqkCFB0Gs8uQrH9sxOXDD7M3CfUBAPkTRf9lt6cCqzqrP82J/GagkleDqqqrTz+RsZktpJKoq9YVR+QoXa7Q4e6/dW7iFzPhfwzG+VTBf3aedBO12LLX1tyctpA56F7hYD3qqn/3KXcbgxea1ZJIz3rYDD2lhs7FDybKrAHzq76yQlLOGMXHewlu6S6BCx1yMotqfR7QVlPm2f0NA+G9jpLjC4u/hrqEd5ac6idjKFQyGNGAIMHmCA18P4tcw7jD4xhqYtYg6Ld6K/Jbvls246VU7T8VsZj3NycXYUsO68ZRRqy3o0FttJUmdiNQDSYnsrmv8X/T8Cx2gtcTw9oHFX1uYcXLfeZYYlRcVp1QNpE78qbjhkcWiM9q4AuW6ABIIIAZVkROUQSCARrqQV3HYa5xUgvd7tEBItKZVpic2up2EzpOg3NVuE9osYqG0cOL62vq3A0cQI8Q2gjUHoRXP/ISfHKLfx3c+E12ug7xfiN22V+kQUDFBdUeAH9/aNhrAE+UmvDdX7w+NAuIcUv4treGXD3LVxzIe4wJVR7TBVjUEg5juYk1q7l7KqqA3Aog5m8fhG4PP0OtdGnavlHNq6T08bhu4Zx+1aDAq7S0+ECNgObDpSz+0Hj4uC13alDLSWyksIHhK6giSDrNbOzVl8XeyhctpBLvMnX2VURAJM6mdBtqKodvrCHEpYsqALNss53ILDOxY+ShPjFGpSUs3RnNrIK4Dwg25xV5ZDAMrsQSCSAfAJ0JiOZ5103h3ae13MmCwAyhIh+Qyxp68hqdqXeHYQNhbVtxobaSNiNA3xBq5hexCZUe277eJc+WTEHUDc+RWtiUkLqW6fLC2D4c+Li9fJCH2EGnhPOd1B0OkMdCSPZBy1YNtQEllHJiSwHkx1PoT76HYTiDWgtu6hAEAEDkNAI2P8s+lFrF9XEqwYeX59DTEzl/G1FrGPZU5UunvLJ/4dx5mOgLhlK+cRvTt2T4s16yM4h08LeorX2o7LW8VDqcl5fZfkY1AccxPPcfEHDg2ENq/cWIlFdhyzFnB9ZyzPnXK4qbyujq3zcYfaGVGrOqitFWVNWi8nPU4MqlSpVBRc7b8B+mYcosd4hz250GYAiCehBI9YPKkf9nXFGw73LVxSpVvGhEMAd9Oqt8m86fL2Hu2lLnEWhbQEsbiFIA1JZkuKgEc8tKuJwV7H3RctWVtlCAMSxK5xzXuyoLKRsW1320JjqS3yuzo06Sly+ipxjElsRiWUF815FUrl0BwtkgjMQIBJ+PuoVgMddtHDtiAq3LZtXMkk3nIW4Lua2EzLoQRpl3k0T7Xg4FVzMO8vZh9SxttCqAWMg7SoHP4Ug37BtKEzsWuor3dtA57xF0AOqG2zdSfKseq12js9P6L3efD6f67D/aj9ol7GK1i3bFqyw8WYAuwPLWQvrv6GrH7LbNotisMdDfswPMLnDe/6wfOkxSJMb8/w1qzgsY9i4l22YdGzA8tNwf3SCQfI9amtR7ss9R+hhaLiO/s6R2A4fdsnI41VmDgbADMD8SykdZ8qt9o1bB31xlpSyuRbuW13csfDlH3p/OdgKsYLjYd1urZdWa3N1SNAxyxBAOuwnYSAY1gff4qz3S7qRdSQixmS1OhynRXfkXEjQgEQRUtLSXOHnlvJ5F67duqX7QwcLUWA2IxRHf3Y8A1KKJy208gCddJJY6SRSpxXHLaU3GIUFoE7AsdPWN9OlWCZJLZmJ3Jcj4wPxJqtZxyd6UFtUYAHNGYwZjYTrBOp5Gup3UrEyzmUK6y6Rh2c7WtbsNYw9gtfZ2Pet7DBv719Z09mNB4RHJau8P4A1wNbzF7l7W9dbmN29AR4RHNh7g/Hu09vDAhLbXLhiS3hEkEjMdzoNgI5aU5/s97S2MTaCoMl6JdSZLRAYqeYBIEcsw5MCYzu1K+XCRe17cbpXfkxSyxJAUyNwBtGkGKO8Bv+E2zoVMgHeCZPzJ+IrzjOOGFV7sSGgR+/sp940/lXrQHCNjrrpcL5ACGAIGQqd1jfUEwdI0Osa9VUp7OKZddDo6giCAQeR2oVieFJqyN3ZE6g6CN+cge+PKrtrEyYYRO2sj4wINe4jA23BD21YHfMAZ9evvrU89GYx2LHCO12e0bhVmQErmIymeWvssD5QRzFbcPiL+JAuZ0tpPhyiSRPqDGnXXmoo3xPhqXbD2SAqspAgCFjYgbaGD7qX+xqsMPladHIE9Mqx+M0ltpDwpbDmGuEALcYF9pGgbfYdY5VbttQzFXEGYORChXg6bEx81+daeL8dtWwctxZ11kZQRyGureWw5kSJlKb5Q1YXYxA15Qbs5j3u22Zx9o5SRlzLAggcxuJ5xXlW3EsA7CdnLrHLibz3LavnCsZLNoZYiJAaSohQvISFYNNu2FAAAAGwG1bK8pksG1TfZxH9rwvHFhtO7yi2kzIy+JtIjd9xOw6UrY+0WFt7pLXHTMxnQgMyJ4RoDkQe4rtrTf+1nFFsaEnw27SgDoXLMx94yfClPi90Kbcn+5swOZ+qSYH8U1y2/k8H0vooS0YdPw/wBYKwAA6CrvBcJ3t5REjcjqARC/zMVX+aqCAnVvcOnr1P8Arzp47DcNJhvtXGAU9BJUH3DvHI/dQ1ya1OZ47fC/bOvW1Vp6bphDiWEZilrKYcFsw0Y20zFyo6u2YyIMCRyor2QwNq9hl9kuhe2Rnylhacop0nXKo5a6U33+DW2ZGEq1sALEEQuw1HLyilnjHZOytzvSCiN7dy0Tba22+YlYJtz19md8u3dpaXtykvB8rWqrzu8m7EcJS2jXb5Fm2gJMvncgecBR8D7qU8AC927ey5FcjIp9oKAYmddiInXUzqYDBj+y7qAzXTetrqDdclV2IYgzMaR7RnbWh8AbTHU7nzPrvXSsvlkXhcIUO2+Gkho0gH3iQfgoPxFD+yt9rF03bbMGslbpXcMFYJcG49q1cJ/l12BDhxvC95aOmq6j3b+7nHOKUH4cyXigJUtbu5WOvh7pyQRME6FD0kkcjXFb2auPvlHsei26ui5rx/w7rhr1jH4YGM9q6NQd9DqD0ZWHLYjStWIxBTwBS9wD2RAJ6HXSDv8AGlb9jOLZsNdRhGS5pqDo6KdBMxIJkjmehpy4lw43DIbLpuJBkBwuo5ePby86u1vnJ5upK0dSo8IWb127ac3roKhwVFoXMxllgELmIiRy604XMYi2jdLeALmnyAmgycCXMLndENMQzTlHMjUgAhmXTkE2jTd2tlMHdKaZVLdYIlgdeYaDW6cueyepW4wsYhrpBN1rebZVAAA5SWU5j746CtNx7li79YQ1u4QM6wuVsoUZlnQEAbdJ6xzzA8XuYeyr2w94Nn74OrFUZTAYXQNysGCeRnlDp2d42uKsQwmRDD8RPwIPQg6VSo3Ih7mxlNMTbxOJxVnEWwDZICgmCbZAnnuD4wRqM4HWS3B+zdvvO9cO4WAgcgpKEgOoG4IggHRdY8q/AeEqbt17jBnZlUktleLSDKAByK5WMec05ikmcMq63IrXU1qVYIqUrhBvYm2f2hYY3MkwM2XNByz0DRlJ98dCdJPcV4ulmw9+QQoJ+AJII6iDpodIpLs8MU4dMNbsm4qiHu92R3hmSQJIQHzM+kTXlrsNfdDaN66loiCjuradAcrMBHKRTYpI6P8AwdeUk/3lCZ2mw1++tzGXHRGYKQkEtEAKCxIAaOQEenINhbBNknMzPbaWBMjI8KGQcsr6N/GnnXVOPdlsyrYV87sJ9mAkeyx1OkzPlNIXCOD3hiCpWDbYpcDCVbSGtx9oMp15AGek8/qHOmsvo9T0OsrlunzPS8YK3AeEm++v9mvtGYmBMTyEQSeQPUieodlu7U97PgRltoANS90qmaOWhCgcln0AbEYHuFW2qZbZEjnmEmNeg36sTJ31O9nLDKuY286uQySYCtbJALc9cxiAfZ8xXLoS71Fd/wBL6/LJev8AUPVXx6HB7ygqpOrTA6wJPyqd6uYrIzAAkc4JIB9JB+FCRbueIG6fHBJGhUxEJyC6Dqd9STIl128TIPr2QJGyDKWIb0ljA57ciR6StHkuGjSvAbLuSM6IGM2tkYiNVHJdfswD+KZfcZhoy6sY3jKcpVusTG24ms1x97wFrj57QKhifEIMNJ56jWZmBM15j8YbrB2CgxHgESZLFo6nnHSaT3vosvTvz0Vt9SCGOUEbqfEI+Enf51ZvYBGTNGgVkJ+4XttbQnQkAqYDwdVIIICxu4Ngxduoh2M6jlCkg/ECmGzwi5hybhyukZbigEkodzEaxvHQEc6StNa0fLtdM109C/gKv7OuH3cNfvNvbCoG65SW1jquh0JBBkTXUZ2oDw/ArhXd5JtOqhW3yAFjDHfL4pDbdY3N4YwLKJD7FYPhUHkT+AGsEctappRUwlT5E9Rre7qO35wXrt4KJJj8SegHM+Qpa4txBrwNpZCMCHIAbTRYnqWZR4Zyzz+zoxly/cuwRFsyJj6xojRVzSEJnkNACSfZYjg+Aah2Yr4SpVTqQxUwzjXTLoFgCTlyjSrHO8+BG7R4nurtqwSwsW1AZbJ7tWbd4OuoldCTvrqZBNr2Cs2lu4ZwikgMbjEgNzzZjOaG1g7QafvodvIEyLkGyxoPSqv+wsPmDGyjMPZLjPl/hzTl91CfJm344E7s1g71/ELiV/sFJ+suAqzmF8VpYnJplkwCADrANdDr2pQ3k1LCwa2apWRFSkwxsoyqu93dVEt8h/Efy3/Gp3TH2m06Lp8TM/CK2C2AIAgeWlMYVLGDySQZdjLsdz+gHIVpxHCEe6Lh6Qwj2o2k9Oo5wOmpSpU605rilkZU10A+1eA7yyWA8VuWHp9ofDX3VngVAtoBsFX8BRmlXCcVsLiL2EW4ua1lMT7IuCQnqOXkQOVLqT5KadcbQszQJP676DSojAiQZFajiFzooInMCZIGmw3MnUjap9Fc5y6ksLkeEhRcQkFWMc0VonQk2+hFKoyjXqYYp9osMUvMwXwvBkfey+IeumaN/FMUKtljJXcARqN2g69CF/HnTj2qwTDDtlGYWV71c0ZnuLmkafaYEiYiX6SK5x/tjE22Jv4aUb2e5MsDyDZomeoiKpOnMvLN33Swhp7NYBnxCfcRi3TRdR7gSo9Z6CuiPcABJIAG5OgFKHYa09qwz3mL3brEhRHhA0yrtChpEnnz1FGr9yfFcI02A9kHy5k+floBrVEl4I023yZXLzNKoSqddnM7hfujz33iNDVayJ+rsKIG52RefvP689asWsG13V5RPu/aPr0Hl6+Rq/hAFGWACvTYzzHrr75rRTXw7DKozDVj7RO87Ee46e6rtaLOhYecj+YT/mzVvrAJUqVKAJUqVKAJUqVKAJUqVKAPKle1iaAAXbLj4wWGa7Ga4fBaT79xvZHoNWPkprjv7OOCX79y7jndxBYK+n115mDRPQMAdB7WWNiK6H+0Tstexr2wjAJGUtIm3mIzEAnmukgTypt4fw+1ZsrYtoBaVcoWJEc56zrM7yaR4b5KTW2eOwdiuKDC4a5iL5aBr3Z18ROgtlgGhiQQG9nyA0U8V22xr2GUYG4r3Vy2ntksoL6AkZfCddMx3jYUY7Y8DN25hizn6MjnOjagMQAjE/dGoM9Y2OhriV+1bVUyo7mAibnXmd26mdzQ9zfBaK04lNrLf74FCz2ZxlizmtYq46FD3lq4e8RljxG3MFNJKxJ9mede8J4dcxBzgtbsg6Erq8bkBhMchtrrJjKWtM7J9eUVfuJosfvmTI/dGnI5qp3eK95cFizqxiY3VZgsfuqBzMTsNdC8ztRHU1Hby/8AmC3h7K2wLVpZPSZ3Mku3vmPMbCKIYTAZTmc5n+S/wj8/KrWHw6oIUR+J9a3UEyVXvyIYbjl1HMevMennVipQBXQguT1VY84LfqKsVSTw3QvIqxX4rI934EdKu0AStV66FUsxAA1JNBu1/GXwtjvLaZmLBRPsrM6tHpHqRSBj+LYi4jtdxBhCoyKiZZYSANNY86WqwNM5Hvh3aNbt/uwIQg5CdyR+AInTy84DFXFMJxC4Iuqykow9oBCCIIgjT4iun9nO0VrFqcoKuvt223XzHUefxilht9m2kug5UqVKoIVfpa973es5c3luf0Pwq1Sjh+Ky/eEuoRYYXFnRvSCRoNT50Xs8aRhoVJjQBgCfc2UiprUljuGgleuqgLMQoG5JgfGhF3jttwVtyxOmaIHunX5Un8afG3GLXrFyB7Kp40UfyzJ8z/StWExWV8pbLCltZ5Lmj13qiwxHk6FbukgZtPSvL15F+1vzpZtdopSPnV7B4K5d8VwFF5Ls59fuj5+lTenyOq4CuJuK6m2AHzCDHsiRuT16Aa7bDWheBwFvCqB4nuERmbW408h0Gmw6czVo4yPq7IXTmPZX06+v460oY/HXhiM1v63NplJgyp0ZDrqZ212XppRLAuRxs4RrjkXQRCgqo9nxZhr1Ij5+cV7gMIq4q+wgFltkwOZBU/K2v+jVbCLiMSJuM2HQaZE0ukwJLN9kfjPvN7hmBWyxAZ2LyWZzLHIQByHJqDArUqVizUAe1K0pdk6bdawx13LbdgYIBg+fL50qpPk3BtdASCRqpkeRgj8Ca2ZqUTjrmdvGTbZMsGR4ifaHh6aQIrC2pS47qxh0yFQPD677+cc6l76K+ywnx3jFoWri5gWZGygg+IxGkiDuKTuI9l/7T6wBA5PNjJVV19GzddKJY82nINwoCu2Z8sTH7w6VYwWKtBRDSOiKzD4gHnUa1Wy06SQt8K7Ohy1u7mCqZIXQltBuRtANEOzN8Wscbdq2sOShYliwVAWMEtG69OlH+I8SVlDBH0mYUqdBzmNK56b0NIYqZkT4dfI/1pfcaY06apPJ0zivayxh2yvnJ19kAjTQ8xzqVzi5neCwJI5n41Kb+RQL00jhYxlwtDEPCMVzAR4SuhiJGtVcZxKxbGa9bsqCRqM1v3ALJPOi93BhXRl1QyJ9VOh94FJHaXhjO6uQWVVIMctZJ/D4Uif2ZhBfCdpsGTCXbtv+EkL7ywX5mj6MXgC61yYIRkBzL1zyQB5zB250mcC7GHEFbhzWrfNty46ID/mOnrTz9Jw+Cti1bCryAJEk7mSTLNrt5jYGrxGeX0Sp+F2Y8K4Jawq95dYM++Y7Lvog6gfa332E0L4r2n7wlLZIXrvP6/hvvoaXO0vFrty+9t2IVSBlGx0DCevLTQaDnqa1hh510p5INDNh8dlViCZgwec+fvodcHyIPpBk/Kt3DEz27nUDT4E/lWpxOYdfzEUyMOiEuLvszbYakaFWHXqCOmxHnpXxrlL1pgCVbvF03zEIw+Vtqu27+ZEfk2U/4v6kVr4naLIQIndZ2zL4lnykR76R9Gon0w/cf4f1rA3yZ8LCeo8qWUu3yA3egTrAQEa/Ci2FulkJO8GY26aVy+42dHt4LyXWXa22vp09K08QuOyZYKZiPEYMR4tiP3aEcXx7K4toBJjUjrWpMQ6ZmdlIVGbRY1UdfQmsep4Bafk127ouXXtZrjG2BLZsupAMQkHZlPvqrxrLaVQttbl13CqHU3CATLtEkkKsmARy11rT2YaQslS+XMxFwuczrbLZhEAli3vWOVUcfeT6XdZu6hRaQd5+6HvNA5ycq+sCmULckY9R7XSC6sCAVVVBAjLAG3LbrQa3xLvL+dbv1KAIAGjM5fxtl3ZQIWdtSR1BHiT9zhmMQQmmnMCPxoRwi9lt27Yv2WhLS5F1eZNy5qHM+Zj3Cl04T3N+BtS2tqXlhbjOJK2nOYaiB/NA/M0sWrpHt5Y5noIOpoj2lcFFWYlp2+6P1IoJcYLJCFsqs3hMQdl5g9RprUYnc8HS62Q6HLs3xC2VdblpGykQYCkSJIM7wede0hvjri3GW0W0VA+aQ2aDvOu0VKpWnhkZbazyNvAeJtauC0qs63NDb3nbUee/50yYTsvZW4btwsRMqjMSon7+sMfLb1qxasYbh9pnZgDHjuN7RHLX7Kzso35Zjuj4zt5dxN9beGQMAZCsPaG0sPspvrufflqyhQsskt19dfYwdqO2YtTbsK1y50UGdOWm0cwIjmViCtYLsm2Jm9xJixbRLSzFvNtGUb+fuGmpYuHcEtYdzeQeIjUEljbVjqqnTwSDr5CetFcbZLrAMGZnXoRy9flU3qNtfQ+FKe3sQ7/ZjE4Yi5ZK4uzoQlzw3gI0yv8AaERo3SrfBeKYa62QLkuLJNq4uW4s76H2hruJFPFi3CKrHYAT6adaW73CbOIDLftgsAMr+IXFbXVGnNOvLpWf5J89DKsNJrssYe+FEKpAjkOhjr76plQDHTT3A6fKtNnAX8O0G93to6A3FIvKeQLAQ48zB8zWC4kZnzEDxaE6CMqjn5j503psq2si+oS2po6DwC73mGQcwCnoUJUH4AH3iiTAlehifQ7/AI0pdiuIKC1ufbY5ddyqrPvIk/y9ab82seUj8/yrrzk5WsHO+O3Ht3nVWbKCrjUAZbhJUQTqJVl0+6fKheM4vdbOwLoqhQ3dnKFzEgEDNuSOU009tMDORw2UzkOgIbd0BMSAJuaikrHYVkzAyCQsiAZyyRBiftHY1xaiSvB26TdRksY/jF26AxXS2AGZdPaMCfFJM9BpNFuzOJb6KLuZnfPcChvEYW8y68+R90UmtZcA+JYaCQV18O2sSNtpp37NDLhLRIQDu8xJMRmJcktHOZ99Jx4KVnyGcOe8WW0kAmNweY16bVSwVxnnNK7Dcjedga3YS+biK9uGRhIIc/morG7fYHxW7n/I3/XPI8qGhEDeIP3d1bYGYGN+RJjTl0q7ZwJMzp66/n0iouMTm1yfO20D3hI+deDHJqFu256ZwD8Jmlwa8iv2qXLeVAx8KidJnNrB100A+NArdqXIkyfukj2SCJGx1PMUW4yGa9ccoSM0TrEKAo19BQlcUqvIUkjz010oTafBXbmcM8tYfu3uMzEs5BMxOmnLSpWOIvl2JykfOpW5o1TKL/a3A38Q5a8XMHRAzKq+7r5mT58q2dhsP3QuKqgHMCSZJgiACTqdjzp9wvF8Ni1AuAK/3v6/kaxt9mTacskMrDcb6HSR8aem2jkl4eGbMFh8xUyS3LLp8d6I4rDBTE6xO50q3gVW2hPONaT+IcYY3mMkAg/IilwsIMt0E8cyW1zsFAkeJoAEmJJP+uVD07QWs6oLqNJAhQRuY31HPnQLi2LNxGXOWJ2BJOxnSl+xh3Vg2VtGB26EGqxt2vKFtVuWGdC4teUqCGUnMNAZ5NQPu0eZAOV9DzEw2h/mrHv841zAfA/DlWeGX2o8tfj+lHp+LG1mtmD0N3QlPDlgrHIoRHyC10Hg/FBiLK3VEH7S8wy+0PeNvIg1z3GaofSfhv8AI/KrHZTin0e7DMe7eFaYhT9ltOh0PkT0qr+Gp+GS/wA4/KHftJhO8sOBqSsiNyU8Yj1AI99c7wvFEM22VmgmZBgCYGQx0jn1rqqr9noRHpuP091cq41gWtXriBwAG8Ij7LeJes6EUuvPkbRrHBhiMOjqWtOXjNnGnhg6ab7b1s44ot2MJZdiqBV7zSfZCAac48W9D7SXVkq4mDBHpz0pg4viLN9hqV8MBo01J0I+GvzrnXDL08rs87M8TfuXZ7q3AEz7AFG8bOpI3Ox99a+EZnZr7LDX/EeYUd3bKLM6+HXUCCx01rbY4TGHuW1gG4T4gJXUAT8BQ3s3wm9hnfvLgZcsJDEiSRJIOxhVFO7l7sk1FLbj+y9xLGMuW1aP1rsPZBZlSfG+WI0UGJ51ZvXjkDMARlkxqNp+FJXHuNNZxF7wBsyoqsw2KSZXTXxH5UwYiRh8oPiyhTHMmAfLrSVKUL7KS27a8AawFb7JBHMeE67ajWsL9oZWOsr94TrE6E6079m+zpcAsTHOfyq523wCraQIsABhp5xSqXt3FHqrepRynvCeQ+Y/WpWrHXirRHyqU+0fevsaMNg0t8nj1H60zcH433egdo6MQR7ulCjftAf3Y88n9a0rxO2k5XUt/AR8SDFL+TnfJ0HD8QtXRqQp90UO4lwHNqERx/CDSrb7QeafA/rVrC9sMpgOB5QY/GtzntC7WumZXuEBZ+rQeiqI+VBbtkL974j/AM042+PYe8PrEE/eA/0fxrG7wsXBNm5bcdCPF+P6UYN3CT9JUezqR1Kx76JcI4oFuaojqR40lQSsjUazmB2PqNJmpxTDPbYZ/CRsO7MfGdaEYjiBGgKnrNph+dbLw8oHysMZeKPh2UiwbhY8ngKARB130k9aHXsIW5R/CQPzoC/FT+7/AID+tD7+JzMTmUTyybaDzql07fIsTs6Ox9juKm7b7tj9Za8JkiWT7LecHwn48xQztzw4aXsqHIMr5pnKXAt5YYDdyNTqF02ikzshx1rVzus6G251VrRK5ojNoZByyNPKnW1wg31LPh1PtDM9x07xi0qYyk92IUBWPrMTV0t0YZB/G8oUbCI3s2lnykH/APtV3JcP2MvmBPuILmlx8XkJRzazKSrBrOoK6EHx7gg1h/tYa6WfL6uP+quRyzqVDlgb963sTHQpI90HT3UUtutzdWU+hj8K5ne4gCQQban91d/+aiXDMaf+II8tP+qlcGqhyxfDMwIIV16ESPgdJ860XMFLII3P4f8AmquB4oq73R6E/hrTJwm+Lh0ZW9DNI0xtwy4BAttQOQpP7d47kOVNuIvqiQSBpSfxnDJePtfAg1fVrhSQ0V8nTON8Q4rcW64VRExr5D9ZqV0a92dQn2z8BXlYtXBRwme3rVttCLxHqgrX9As/cvE/xL+tERbT/wCnc+9D+NyvbYtzH0dgfRPyep5Y3BQ+goAciuCebMD+tULvD2P/AJH6U3WeHhhCWDPov/dVPivCMkDKHbcgZYX1kiT8aMszKFX6PdXY/P8ApWaY501adNvFz8vlVy7w5ydLI95T+taBwslivcpIAP2ec/pTZFb/AAEbXaW6BlMsv3bhDj5yapYrFWX1bD5Sedu4VH+EyPhFYjgryIsWyJGaSBoCCYgGflRhODSpYWBA3MrpRwAuNgLbRlB/mLA/IsPwqtjOFlR4VIM75yf1roXAuHWs4z2lA84j31v7WYewuWLaTzAAGlMnxkxvnBy3AZrd1GaMoYZtfsnRuXQmu/qmhXlAg84iPjpXG8XYtsCBYXzkgae5TXUuzGLa5hrTNvBU6zqhZJnzyz76vo1ngjqryc6/aRwUJiBeySLwkwxADpCtp5jKfjSvYwIYSLbf4q6/264d39iAqk22DiemqtyOwM+6uejhJDZSlkGJ5a6x93/Uik1eKG03lFLD8HXnbf8AxCiljCImy3RP7yRW/DYBl0OHw7D1AIP/ALZkVd+ipH+7Wvgv/bUG2XWAV9HvBtM0cjKTHmKZez2Ia2Wa5JyrKjw6nblVBrC8sPb/AOX/ALap3caikq2HUEdCPiNKwG1jDDHEuLXGJJRvdl/Whhxrcw3vC/rVX6ZaO9j5rXl3HYZRL2oHnH60YYbpwWTjj0PwH617QfEY83INm1CgfamTPkDpUqns0R902dn+JYi8wBYkfuqoPzUz8q6XwjgaooLSSddfzrDAdnsPYuZraFR0klQfKf1ii2MxORSQCx5Aamq7Zy2xN1YSRX4jihbWFgHlSRjWZjIvXPdk/NDSt2z7RXDdKuGQ8gwKH3TBpZTjNwfdbyZEPzy5vnU2nXJVYlHQntECWxFweZNsf/HVZe5Uk/STJMn6y3JMAfd6AfCk7C9oSjM/c2izdBkgdAYbT3bzRa12zUDWy/8AI6H/ADFaVy0MqQcu4y3lOXEOTGkMu+w2XrWaY5gMvfnXcZqF2u11g7i6vqs/5Sa3jtThz9tx/wDjuf8AbSuX9Dqki0vFI/vv+Za04zGo+r3PL28v4EVr/wDUVj/ikequPxWqN7jOGN0u13QKoBOYD2mmdNfs70KWFWsFhb9lJHf5cwgjvokTMe15V0bsLcDYXKpnJcbczuRc3P8AFXPP/UGG/wCJPojn4QtFOz/bexYubuyXIDfVuMpEwwlQOcHyg8oNdF4rkhq1uXCOo37YI1EjYjqG0I/D4VynivC8PbvMlxrhuLI0uXS5UHQ+FpiCD76fD2ssZZVi/SIA+JNcm7TdrRcu3WVQSbisCG0AQIsDTmFIJ8yavrTlE9J4YY7qyBp9JPo+JH/VWtgMwyHEgEbFr2keZPP8qWH7Y3QIVEH8Ut+lUcZ2oxJ3ux5JC/OJ+dc3t0zoVpDtcBAzFr4A5l7oHxmKC4zi+FGpuXLhG2W5cb5lo+dJ6LfxLeBb19toUPdI/GKaOD/su4jeILolhTzusC3uVZPuMVSdH8i1rfhA/FcfB0tIV6FnZj8Jj8aw4LgcRi72W3be6w3O4WfvNso+FdT4D+yPDWobEXHvsOX9nb/wg5j72jyp9wWBt2UFu1bW2g2VAFHwFdEyp6OWqddixwLsslq2FuQz6TGw8h1rymi7ak1Kg1WSypExFa13qVKWuwnoE9uv90uehr50tbCpUqtGSbDXgqVKRjkrwVKlBpuWrA9h/wCE1KlYYeYnl6D8KovUqUIGFsN/urepoNUqVWvAk+TAc60PuPWpUrEMz6h7I/7tb9KNVKlVIMlSpUrTDGpUqUpp/9k=",
  atributos: {
    Atk: 6,
    Mgk: 8,
    Intel: 8,
  }
}

var cartaM = {
  nome: "Senku",
  imagem: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFRgVFRIYGBgYGBgYGBgYGBgYGBgaGBgZGhgaGhgcIS4lHB4rHxgYJjgmKy8xNTU1HCQ7QDszPy40NTEBDAwMEA8QHxISHjQrJCs0NzE9NDQ0NDQxNDQ0NDQ0NDQ0PTQ0NDQ0OjQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAKgBLAMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAACAAEDBAUGB//EAD4QAAICAAQEBAQDBgQGAwEAAAECABEDBBIhBTFBUSJhcYEGE5GhMrHBI0JSctHwFGLh8TOCkqKywkNTwxX/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBAUG/8QALREAAgICAQMEAAQHAQAAAAAAAAECEQMhEgQxQRNRYXEiMqHRIzNCgZGx8AX/2gAMAwEAAhEDEQA/APKqijxCc52iihRIaINX5HkfWAqBjQ25wYBQMUKEg3hYUR1FUsuoqVqgnYNUJRLJxyRfhDKRVAAnnv59PtIAIQWVyI4gVL65s0iLSgUPcndj6kyppj0agpUEotnpfA+AYWEPnKzO7Ci71YsjUKHLeN8SZPwXz0myOpRv9VI9xNP4fdWwgeaOq6u3iUb/AHF+p7Qs4pUlXOpVWjf4ijH8QPUqav0B6x7OVR3bKmQ4mmIiLr0sL22tgELH6kTGxWCgsewH639xOZzKPlcbULKK9gjlV8vLbabGexjjBWwiCl0xFbKwFn1FEVCtluKZt558bAc4+I4/w2CQuGiN4mOnSCw2FarJ36dpyvFOPnF1BF0qxsk8z5f32ln4k4k+Kq5bDRm0HU9AnfSAP/b6zmQa6b/lKSKSJHJFgjeXOGYHNmYhV8WnoSOpHlY+srYjWFI56ab22H2qRYmMarp1FyiiTiGbD0FvSPue9dJDlcdVux1kFwWaokIsZnM6tgtfmZLkcoT+0ZToUjUegJB0361ylTCDDfT7nnNHExWKLhrelyHKd33A9wD95EpPwaQjH+q+2vsrs7NqeyNxVdATX5SEy1mFCqqKQWPiejYFbgesrRSHEHSY1SVZIcKQ5F8StUQEIiPGKgYoUQ57xDAqKSYoAYhTYs0aqx0NdIEYNUxo8QigFCj1FUQiAeKKKA6FFFGqAhVGhRGAxFjGEVRwICHAkirGQSZFhYUD8uF8uWEwpOmEOZF9xyhYUdr8D5oHBVW5C0YH1Ok/91e82OIYXg3NFLAbnQ5AnuCNjOM+FMyyOy1aspYqfKr+xP08p2uMNaEBtj+FiLq+jDuPuLm0exzyVM5hls6SltvsBq1DyH9+cgfJnCfQUVA6EqF5c97FbHcfWdNhcGZCMRD+0C1V2jja1PkaG/TY+UfGya5jBR11D5bNYrxhdw6kd1I3HXSa5iLkh8WjmXQ4q0iksCGFEXqXYEixYBM5bF4DmVDu+GQE3bcWQdywA5r3IneYnA3wF+bh4mrT4+W5H9Kv1uavBOIpmQUZAroNRXmCDtY8jyI/0hyQ3FpWeQhwBK7G50Xxn8P/AOGxrQfssTxJ2X+JPbmPI+U566Ed2IFqjZZbOrty9YG52H0ltcOgB9fWTKWqLhG3YsQEiOzMuknY1QPkB5+sSut7/aQ42IWN/SKKdbKk1eh8EgMCe9H3hOKJHYwSnh8+cSiEnaCKphCSfMkdQyxoDoOXlMzVEZEaodSxg4QIuJugUbKsVSfMIBykQEadg1Q1RVCqKoWFA1FUOo9RWOgAI9QgIS4ZILdBV7jry2hYKNkRWNJCIJELE0DFHjVGKho8eooBQ1QgIhCUQsdDoss4SwFHlLeA/kPpBCLWWw5qZbhpbkLk/wAPYSO/jrQpAbSBqLEMQo/6TZnqfB8mioWTLIB0LGyZtGGjCWRJnlH+HbCdXGxU3/Ue42neZXDTQSKIOwA577jkeU0OKZbANjEwVQtsHoFQenp6yjl81TIiqqr4tgoqgp0/35RuPFEOXJouYOCFAA6Tn+J5o5TMo4P7PGB+anYoVX5g8/GoPoJr4mPmEJb5eG6VyQlMT2DeFvSxMXi2by2ZR3w8VfnIjqMNjpY0QzI2G24JKDcb7DpMezs176ZaxuIphO6P+DSHUgWNLMFaq/d8Sn3boBPPuKpj5bNl8EmgLRhupwzvXZh/SdTw4ri/LVm2dGww3axan3Kj6ytxrKph5PCXFxEXxHQ41DUjF8SitWLUAV3IjTXcUXyVMTcYwOIZc4OJSYh3UnkuIOTKe3cdiZ57m8m6MyONJB3v+95ZRbZmDFReoLVtXeh+Ees2MtjJmVOFjNpxF2R+pA6Hv6S06M5Jx+jncsqqrMSNVkAV0oUfqftK7uT3m7mfhvHTbQWFkgpuP75SjjZHR+MgHtqBP0HL3i5JGquSVNGcATLCYZHPn+Ud1Ciwd/73kiPquhtt9a3hJ6tFQj+KmRMlWecZVoScrB0TLlo24U7IxFULyqICFhQ1Q0ciDUeonsdDOxMbTHqPphYUCBFC0xwsLDiDHhaY+iFlcSOoqh1FCxUDUYiHURELCiPTHqFUaoWLiDUeo9RwIWLiMFkirEqSSCdjcaQ6b16D77ydAJEhBA+h9v8ASpMglydMiCuJsfD1/NC9CHNfyIzfmPvPbeFOVy63vQUC/S54r8M/8VvLDf8A7iqf+89iGJpwFHn+S1NsTuJy9Qqlr2MD4nxDi4mFh6tKkszV2RSx+wMw8jmsYkOU8CaWtSGAFAFbHMgFifWT/EOOQztf4cvi0fNho/8AecAmfxVGlcRwt3QJG/QxZZVoeCHJWeicR4ewxvmasU4T/jXDdwUagA+hSCymt633M4/iHwtisXxC+s6hopHA3PNnZQVUe57nrO0+FONDM4VMf2iUrjv/AAvXY19bm8DMuWjVqrRweW+G8fCw7NkcyoNulbhxXMg9BvyrlUocR4dj5rETEIXEYMoABUoFHMhW2ANWbB3Fdp6USBOIyDYhfFdAWCOVbSaZ1LMFde7AKP5hXOt5TIcXFuSX2jN4nwnDymDiC0QPQdixfEcA2EQaVCgnmaJnEoC7l6IUtfPer5Cddxrg6Zh2dcc6yd9YsAgAUaopVcqnPvlWwzocUR7g+YPUSpSqOjTE45ZUaWDx50tVtk/dD0WA7E1v67SZOPC7OGvmCoP35zEfbnAxGroZnGb0kXPpMe32+hcacvilwoCsBp01VAeXW5HhDYbV5Swj1sRYI5Hv/WAiypTuIsMKm4+3+gSsEiT1BKTLkdjiQMsc4ewNjf6j1krJBCx8ieBEUi0zUzme+ZhorINSWNQ2JTbSp9N9/OZ+mCk2tjlBJ6dkemOFkmmKoWTxAqEFjgQgsTZSiCFj6YdR6isfEq1FphVHAl2ZUNpiIh1EVisriR1FUOoqjsOIFRAQ9MWmKw4lpakDAXEc0FTSqhmY3vyA6QMLDrcmzK9Pjtsz58nSQ2C5Wx3238uRlpG7ipSxdveTZYGrJ26D9ZrOnGzHHyUqOo+E0vEc/wCVF/6sRD+SGel5nNfs0H85ofzV+hnnfwxqI1WbfFVbP8OEhP8A+gnoGfQKi10QH82/WdPTY3KKs8//ANDqFCbS76OQ+KsXwYv8qL/1OhP2QzhrnV/Ezkq1YbuA6WEDGqTE3NchOe4TwjHzLVhJfQtdIn8z/oLPlMepj+J0dXQS/hJv5ZN8P4uIuZw/lNpckrv+FrB8LeRIH5z0XL8b+Yj/AC0vGTZsJiAwN0edWOt+XSUOGfDuXyYGJiOHxBydvCqmt9C9/M2fSc7xnFVsdsTDcjkQy2pBAA2+kwS0dMqk7R2+b4qUXWyFF/icFyP+RL+pInN8R+IBpPysRwTuzlUQEb3zBY/apVwPjA4dLmBqB2DqN/8AmX9R9Jw/F8+2Li4j62ZWdiCSfw2dIA7AVKjFsltLuWVzDFy6EgcgbNtQok3z95Pm8cvpJ7V/f3+sq4C0oHlJKmblbaZr6VJTitr9RqiBDcjyNe8B1LKQDR7yfBwdKgdPzPWQ9L5OiL5bS0Q4it0/38oSyaoJWh0r+sOVqhPFU+QwEREICEEJ5TOzaiKoDJLL4RECNMTiPlcNCTrcqAOYXUSewFj85XZd9pOVjMsd7Bx1RDUapLUVR2TxAAjgQqiqKx0KKPUeohpFWo9SSo1S7M+Igm19vMX9Iqj1CqKx8SMrBIktRiIWHEjAjwqiqOxUV8thkWW53W/YcpY16Qdt6oe8epq8O4Bj5hGfDw7Cn8RYKGrmqg8z58pak27M3CMY1dGSUB5gGScvSTHJYgcYZw3Dk0FKlSe/Pp58p3Xwl8MKpGI4V2G4ZhaIf8inZm/zNt2HWVjxym6Rnmz48Mbb/dlHhmWbC+ShBDKpdx1VsQ2FPYhAlidHxXOHQx/yV9FqdZw7gyKLCjcklj4mYnmST5ynx7JKQUKggqT05dZ6eOorij5vqE8kvUflnK/CWNrfHPmn3D1+Rl7iPEsLAxES2V33pF1LV1rdfY7jelPaYeCWybs6+JCtOvUqNwR5g/YnvOfxeIPi47YpawwNf5RWkADoNJacmeLUm2en0clKKivB03F+CYrn5iYoxbFgNSmjy0EeGvLb1nL5nDKWrAqw5qwo/Q/nPQOA5YpgIGJtvHR/dDbgDtt9yY3FMprFnDXEUb6WoMPNG6Hy+85kzuT3R4xxLBdX8ZJBsqen06SqpnRfE+CjOj4WrQRRVxRRievcHbfymBi4bISGFGdEXaMpKpE2Vfc9vt7y8puZm9A0aPI1sa7GHhZkrXI1/dSJ41La7muLM46fY0MIdPfy3h3z+o/Ig+XKVcvmNQoEA1td70I7qxTVfiHOvuDMlFxdy7PRvzjKNQ7rZaRwQCORiCCyepr7QMlgsMMEg1fOuRJJA/OTVMJabSOqNuKbQNSbBYDnI6jESHsrsTYmJYkFRMQOZqLDdW5G+8ajSsVq6vY4ETLDAj1FZVFeoqkrLGqOyeIGmKpJUEiFhQNRR9MaoxUJsOMije75bV38/KWAkhKwUhuNbAqOBHIiAhZNDERAQiI1QsKBIgVJKjaY0xUOoWjqJB2raxXX+/Kdrh8XfBIRApwkFIvkNgSRzv8AEe5nCq9kg7dB7GppcNxq8Bsjcr1qlJK+Q29JrFU6MJ1JX4VnR4/H3cgYioQSKVV00b8IB8ydJ8jO5ws/hqAAwAr0qef8OyWp1xHPLdVHf+In9JLxLiwU6F3bUFNfxGqX13HpPRwXBNs8Pq+OaaUPC7nof/8AWZRStQNAcjz5VM/iOMw0sxJL/h6s3oBvynLYOdOGQTuoNkHp0sedEzr8vl/wPibsed/uoN0wx23onuR2AmmTMsatLbOPDglmlxk3S8nHfE2G+ykFQwPpfax1rpMvhuRbEXQFY6WUs6gbKSAwskC9O4s8x5zf+LeInExPlJvot8RhypaNe23ua7zZ4PhLhYWFdDbW19XYXuff7eU5Z5eUbkts9LFh9KfGL0lfzsx8jxVxmhgBdKC0CsdTUE1K2qzZNfSTfEuBmMTEwsNA4RnTW6EjSoJL2QbU7Cif6zC4Zm/mcQXEY7M7V6sj6R7DSPeegznTrZ2zVNHIfGuGiqmpQA7MusncEDUFP+UgN6UO84zN4qOnJMRlJNWLocztO8+LcyjL8r5YxGFObshDR07Ai2Ivb+s5/hPBMvmWe00sipei9NtqrndHYHbnc1jLjG6IavychhH5z+LZRyUS8/CkCkgbeZMXG+FvlcfSpJBXUp7r1H6Q/wDHWnehfrt195pFpqxNUzEfBIauvSEmIyNZ8r8xLz6norhltP7w/DXUecp5sDVsbH0rlJaTVMItp2jYTNHRoBGliHrrsCAfoxgypw8gqe42PmOksYzEUAtkn2A6kmefKNSpHrwnygmxO+mtibNbRyjMKGxr1qSadxXKt/Xy8qjKjBhyC1exBJ7A9vSKxtfZn4mVbWFZrsE2vPb15S9hYQUUBQhYuVt9es+g9O/aGFlTyWlsjFiUW3Xn9AKhAQtMcCY2b0RkRqkumCRBMGiMiKodRmjsVAVB0yQCNUqxUTYblSCDRBsEdJE6yXTGZJCeymtEAWOBJAkZllWTxIyI1SXTBqOwaAIgkSQrBqOxNFZ30Nq0hlagwP6HofOSrnEWmTUDfI1sDsd+uxMNkvYjaS8N+G3zDEYWwX8TNsi7bAnue06cc4ur7o4c+KUbcXp9zb+FuJ/Mc4ZFULG99QP1m3m+G4aMcT5aBhbFtIvzN/WcbwLBfDx1ZSpIZloWS/MUu2+4ud4+bUPhpiG3LAjDWiF5kHEbyq6HbrO9ZoxhvbPFy9LkeaoKk1sm4fwc6DiOKd6CL1wwSPGQf36s+VDrLfxFxEYOC1HcjQtmzZ2vfnQsx8bi6BGcnZbsdbHT1nCY+abFcu/iZjSJzqzSjy6b+85NzlbZ3KKwxpL+3uy/wTh5xvBuoPixWverOlb7/rqM1eN8eKE4WGFqqJ56ea0B3oX7yTHzC5XL6EPjbr1LH8Te3T2E49iSaB3O5PYdT6wm+TpdkaYMXG5Pbe2S8GyzPjIE5jGVyegXDdSxPstepE9QBnm/w9xX5RZlUEMaI5MAvKj7k+87rJZ9MRdSNfcdR5ETPsXNN7OW+O3OA6YqL+MMr7kWy6NB261Y9B5SbhnCcbDyeOCQmJjAsAWI+WNCoLYb6gBe3KdBxHIYWYQLipqAYMu5BVhyII3Ex/jLjCYeA6BvG6lABzGoUSe21mVzbSRml5OJ4pxH/ELhrjuFdAbZQWLWBVgfhOwmXhOiitV+3KV1tm2skn3g4uGUOlhRmypaQtvZv5PNodqs+3Tse0zeK4IoMOZ5+8r4GYZeX0IhZvNFxVVvflHYh+E2S/oP1mmFlfg+XvDLDmWNj0H9/WWUsk7bDr0vtPPyu5uvB6uBJQSfdjgRwIQEfTMLOmgTHEVQgIBQJiAhVFUVhQwEHTJFEZoWFEZkbSSoBEpEsaPGijETAwqhqkkAmbkaqJXqA6y0UkWKsFLYnErgR6hERVLsmiMw8thqzKGbSpIBbsCdzFUEiMKCzQQO2mylnTfOr2vzqdhiYgy+QwkQ02KisxHUuoZz969KnGTqcqpxcpht/wDSmIh9UKhf+ypti9jk6lW0/Bj8LzRwdTooLEMoJ/c8RupXdzZdmOomy1733uM+HRJU1e5HMXK+DmQWolTuVHQgjoQfznQc/YtnGdxpJOg77k7n0/WTYPgorQogj2kXz1HWz2G5+gjYuYUCy4A+/pAKJsxjE2zEk+f5CVsFi9gdfxvyHovfaRYGMcUEou10NR5+Z6keUvogVQB/uephYyfK5JcR0QeEnaxsQALPrsOU6FOAMh1YWMVPmP1H9JS+HsiHHzFYh0fYH8JFDY9dwSLnYYa2ORB/KQ3ZEpV2MTFyubYafmoPNQQx+23tMrM/DCEFsbEJA8Rrbl3Yzrccsqk+D1YlR785mZvIM6k42IWFE6EGhNt/U/WBKZ5pns6iYjDCw6Qbb/iMz82Q3jNgsBS8/cmbeY4crYhejo226+h7yrxLJKFJVTfO9+Q6Aek3jGtkSlevBihozOJJ8k1qAsda6esiZJRJ1nw9ggYIJrxFjXUCyu/blLeZwlACgVXSZnCsf9mtbUNP02lxsSeNkUvUb+T3cXH0417EOmQZjNKuw3awAPM7QDxBS2lQTR8RA2AHM3KnDcEu5xGGwJrzY9fadMMaSbmc88rk1HH3ur+jU0xyIREYzms6qBqKoVRAQsKEJGwksjaCBkcZhCqC0tEkZiqPUepRNFwGEsECA2LRHrMas3TJwYsRbEJRJQm1SLodWZ+iMwk7pI2WaKRm0BpgsskqDUqwaIqnRLi6MngYa/8AyKcRz/MdVfcD/lmEViy+fdPAFD4e7aW2C3/Aw3Uk9OXlN8LW7OXqItpV7lopOezaaMVlIGlyCCeh/wB7+023z6b0huiaZtlrmfDRP2mZmicZb0iwCVIBs+XPrXadMZJO2ckoSkqX/UaOWdFXkqbbjYX5+cqsFcliAQdh6TCXGYddu01sjmARR27el9+8WWLStFdPKLlUgTjnB0kbr+FvMb/rNhMZWXUpsEShmcDUpEo8MdkZlvarr0Pbv/STGSlG/I5xcclVp9j1HhmEdCMvgcYaBhXhdNjuO4s79Cexm4z6VJNmgSaBJ27Ac5j8Px0xURwByojttuPsJW4nx9cLCY4ZLMr/AC7Kmlar8RPOh+YhFN6OeRN8W/MOCBhqSdarsLPjBVWrsGYfn0lDivEcNBo+bqfDDFQNk2GkIx6mv18hMHiHH8y6/wDF0jsgCE+43mJk3FnX05Hv25zdQfkzs00zyoAQw0sNibr/AHO8p5/iAKlgh3FA1QhZnDUAkVpLKdJ6GxZ+hMkzTB1OkDTLFRkZPNKqlSOZu+f98pBiKGJA6Xp8xzqFlsvqYqSRXaQ4gKsR1H93EBr8IXwH1H/iJpAXKPDDanbqP/FZoATy8/52e3038tERwVIK1sdiBt+ULCwgoCqKA6SQwRiA3Ruu32mVya+DWop/I+mRkQsHFDCx7+UcwaadMaaatAlY1Q4orHRGRAMlkbRoTRGYDCSVEJdmdEUUJlijsKFi4viUev5GRUWdQOQYE+28aKWtf4D9zZRPOSsKFxRTifc6V2Khi0xRTQzIHcK2k9RY84CYgLVGim3FVfwQ5P8AUm6EzNxs4i2NydxQ2A9T/SKKbdNFNuzn6+bhBcSLIW5dj1pfL0/KXAtAAchHihmb5sXTpemjHzmX0sex3EDL45QkbGwRRuvp/WKKdeNtxVnn5IqM3RoZDMFvCTzugelecsNg+LWPCbOx6jrfsPtFFMMmp0jqwvljt/JqfD3Fxl2KYhOnvRIroRXbkf8AST/GfEVbLoMJwVd7LLVeG2o+d0faKKXDumZZklVHNo7OosiHjZUUDe/f9PSKKdfg5CRHLrQ/vvcrPjuEK6dgdj5RRSfA2UcPGKtqB3g42JqNx4ogLGWxyr1q2279AN69ps4+ZZQG0Fr5BbNDqWr7RRTnzxjaOvppyUWLM5RwSMUvhNQcoKDaW/eve9hXkenSbOdzuVwaVMv81VCqzuSPGDdk9T4tzsLrtFFLnFKKr3MoScm5MorjByzDDCAnZFsgbcwTzuKKKebk/M/s9jF+RfQJaNFFJLl3GY1IGxQGC9xcUUuCshh1FFFEALCDUUUaEz//2Q==",
  atributos: {
    Atk: 2,
    Mgk: 0,
    Intel: 10,
  }
}

var cartaN = {
   nome: "Kirito",
    imagem: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQCW_ms3-KBwjBTCG_0xaCJ2wckWPnmDZ8msQ&usqp=CAU",
    atributos: {
        Atk: 8,
        Mgk: 6,
        Intel: 5,
    }
}

var cartaMaquina
var cartaJogador
var cartas = [cartaA, cartaB, cartaC, cartaD, cartaE, cartaF, cartaG, cartaH, cartaI, cartaJ, cartaK, cartaL, cartaM, cartaN]
//            0           1           2          3         4            5            6           7      8      9
var pontosJogador = 0
var pontosMaquina = 0

atualizaPlacar()
atualizaQuantidadeDeCartas()

function atualizaQuantidadeDeCartas(){
  var divQuantidadeCartas = document.getElementById('quantidade-cartas')
  var html = "Quantidade de cartas no jogo: " + cartas.length
  divQuantidadeCartas.innerHTML = html
}

function atualizaPlacar(){
  var divPlacar = document.getElementById('placar')
  var html = "Jogador " + pontosJogador  +  "/"  +  pontosMaquina + " Máquina" 
      divPlacar.innerHTML= html
}

function sortearCarta() {
    var numeroCartaMaquina = parseInt(Math.random() * cartas.length)
    cartaMaquina = cartas[numeroCartaMaquina]
    cartas.splice(numeroCartaMaquina, 1)
  
  
    var numeroCartaJogador = parseInt(Math.random() *cartas.length)
    cartaJogador = cartas[numeroCartaJogador]
    cartas.splice(numeroCartaJogador, 1)
    
    document.getElementById('btnSortear').disabled = true
    document.getElementById('btnJogar').disabled = false

    exibeCartaJogador()
}

function exibeCartaJogador() {
    var divCartaJogador = document.getElementById("carta-jogador")
    var moldura = '<img src="https://www.alura.com.br/assets/img/imersoes/dev-2021/card-super-trunfo-transparent.png" style=" width: inherit; height: inherit; position: absolute;">';
    divCartaJogador.style.backgroundImage = `url(${cartaJogador.imagem})`
    var nome = `<p class="carta-subtitle">${cartaJogador.nome}</p>`
    var opcoesTexto = ""

    for (var atributo in cartaJogador.atributos) {
        opcoesTexto += "<input type='radio' name='atributo' value='" + atributo + "'>" + atributo + " " + cartaJogador.atributos[atributo] + "<br>"
    }

    var html = "<div id='opcoes' class='carta-status'>"

    divCartaJogador.innerHTML = moldura + nome + html + opcoesTexto + '</div>'
}

function obtemAtributoSelecionado() {
    var radioAtributo = document.getElementsByName('atributo')
    for (var i = 0; i < radioAtributo.length; i++) {
        if (radioAtributo[i].checked) {
            return radioAtributo[i].value
        }
    }
}

function jogar (){
  var divResultado = document.getElementById("resultado")
  var atributoSelecionado = obtemAtributoSelecionado()
  
  if (cartaJogador.atributos[atributoSelecionado] > cartaMaquina.atributos[atributoSelecionado] ){
    htmlResultado = '<p class="resultado-final">Venceu</p>'
    pontosJogador++
      
  } else if (cartaMaquina.atributos[atributoSelecionado] > cartaJogador.atributos[atributoSelecionado]) {
    htmlResultado = '<p class="resultado-final">Perdeu</p>'
    pontosMaquina++
    
  }else {
     htmlResultado = '<p class="resultado-final">Empatou</p>'
  }
     if (cartas.length == 0){
       alert("Fim de Jogo")
      if (pontosJogador > pontosMaquina){
        htmlResultado = '<p class="resultado-final">Venceu</p>'
      }else if (pontosMaquina > pontosJogador){
         htmlResultado = '<p class="resultado-final">Perdeu</p>'
      }else {
        htmlResultado = '<p class="resultado-final">Empatou</p>'
      }
} else {
        document.getElementById('btnProximaRodada').disabled = false
       }
    divResultado.innerHTML = htmlResultado
    document.getElementById('btnJogar').disabled = true
  
   exibeCartaMaquina()
   atualizaPlacar()
   atualizaQuantidadeDeCartas()

}

function exibeCartaMaquina() {
    var divCartaMaquina = document.getElementById("carta-maquina")
    var moldura = '<img src="https://www.alura.com.br/assets/img/imersoes/dev-2021/card-super-trunfo-transparent.png" style=" width: inherit; height: inherit; position: absolute;">';
    divCartaMaquina.style.backgroundImage = `url(${cartaMaquina.imagem})`
    var nome = `<p class="carta-subtitle">${cartaMaquina.nome}</p>`
    var opcoesTexto = ""

    for (var atributo in cartaMaquina.atributos) {
   
        opcoesTexto += "<p type='text' name='atributo' value='" + atributo + "'>" + atributo + " " + cartaMaquina.atributos[atributo] + "<br>"
    }

    var html = "<div id='opcoes' class='carta-status --spacing'>"

    divCartaMaquina.innerHTML = moldura + nome + html + opcoesTexto + '</div>'
  
}

function proximaRodada(){
  divCartas = document.getElementById('cartas')
  
  divCartas.innerHTML = `<div id= "carta-jogador" class= "carta"></div> <div id="carta-maquina" class= "carta"></div>`
  
  document.getElementById('btnSortear').disabled= false
  document.getElementById('btnJogar').disabled= true
  document.getElementById('btnProximaRodada').disabled= true
  
  var divResultado = document.getElementById('resultado')
  divResultado.innerHTML = ""
}